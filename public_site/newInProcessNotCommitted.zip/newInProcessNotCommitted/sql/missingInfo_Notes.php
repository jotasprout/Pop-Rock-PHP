<?php

$HeavenHell_Remastered_spotID = '1Wk2g7TV0adbUZ53ruvIdL';
// Above albumSpotID does not exist in tracksMB table
$HeavenHell_Remastered_MBID = '8bbe2647-0945-4581-bc33-576e487bd60b';
// Above albumMBID exists in 'tracks' table but tracks have no trackMBID
// Above albumMBID exists in 'tracksMB' table 
// tracks with above albumMBID have no trackSpotID and no albumSpotID
?>