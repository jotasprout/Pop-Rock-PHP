SELECT t.trackSpotID, t.trackName, t.albumSpotID
FROM tracks t
JOIN albums a 
	ON t.albumSpotID = a.albumSpotID
WHERE a.artistSpotID = '5M52tdBnJaKSvOpJGz8mfZ'

/* 199 total songs in less than half a second */

SELECT z.*, 
FROM (SELECT a2.*, t.trackSpotID, t.trackName
FROM (SELECT a.albumSpotID, a.albumName FROM albums a WHERE a.artistSpotID = '5M52tdBnJaKSvOpJGz8mfZ') a2
JOIN tracks t ON t.albumSpotID = a2.albumSpotID) z

JOIN (SELECT p.trackSpotID, p.pop, max(p.date) AS MaxDate
							FROM popTracks p
							LEFT JOIN (
								SELECT t.trackSpotID, t.trackName, t.albumSpotID
								FROM tracks t
								JOIN albums a 
									ON t.albumSpotID = a.albumSpotID
								WHERE a.artistSpotID = '5M52tdBnJaKSvOpJGz8mfZ'
							) z
	  							ON z.trackSpotID = p.trackSpotID
	 )
                            WHERE p.trackSpotID = p.trackSpotID = 
							GROUP BY trackSpotID) y ON y.trackSpot
							
							
SELECT v.trackName, v.albumName, v.pop, max(v.date) AS MaxDate
	FROM (
		SELECT y.trackSpotID, y.trackName, y.albumName, p.date, p.pop
			FROM (
				SELECT t.trackSpotID, t.trackName, t.albumSpotID, z.albumName
					FROM tracks t
					LEFT JOIN (
								SELECT t.trackSpotID, t.trackName, t.albumSpotID, a.albumName
								FROM tracks t
								JOIN albums a 
									ON t.albumSpotID = a.albumSpotID
								WHERE a.artistSpotID = '5M52tdBnJaKSvOpJGz8mfZ'
					) z
					ON z.trackSpotID = t.trackSpotID
			) y
		JOIN popTracks p 
			ON y.trackSpotID = p.trackSpotID 					
	) v
	GROUP BY v.trackSpotID						